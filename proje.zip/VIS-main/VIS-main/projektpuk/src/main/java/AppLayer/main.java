package AppLayer;

import DataLayer.Product;
import DataLayer.productsDB;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//domain layer
//data access
//dto
//identity field
//embeded value
//relation maping
public class main {
    public static void main(String args[]) throws IOException {
        Product[] p = new Product[]{
                new Product(1, "Nike", "Shirt", 'M', 5),
                new Product(2, "Adidas", "Skirt", 'S', 2),
                new Product(2, "Gucci", "Jacket", 'L', 3),
                new Product(3, "Husqu", "Skirt", 'M', 1),
                new Product(4, "GymBeam", "Jacket", 'L', 8),
                new Product(5, "LuiWi", "Socks", 'S', 4),
                new Product(6, "Nike", "T-shirt", 'L', 1),
                new Product(7, "Adidas", "Skirt", 'S', 1),
                new Product(9, "Gucci", "Jacket", 'L', 7)
        };

        productsDB d1 = new productsDB();
        int i=0;
        for (Product product:p){
            d1.addProduct(p[i]);
            i++;
        }
        int choice = -1;
        while(choice!=0){
            System.out.println("1) Show products");
            System.out.println("2) Add product");
            System.out.println("3) Update product");
            System.out.println("4) Remove product");
            System.out.println("0) Quit");
            BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
            String s = bufferRead.readLine();
            choice =Integer.parseInt(s);
            switch (choice){
                case 1:
                    d1.displayProducts();
                    break;
                case 2:System.out.println("2");
                    break;
                case 3:System.out.println("3");
                    break;
                case 4:System.out.println("4");
                    break;
                case 0:
                    System.out.println("Good bye!");
                    break;
            }
        }
    }
}
